var valorEmDolarTexto = prompt("Qual valor em dolar vc quer converter?")
var valorEmDolarNumero = parseFloat(valorEmDolarTexto)

var valorEmReal = valorEmDolarNumero * 5.50
var valorEmRealDecimal = valorEmReal.toFixed(2)
alert(valorEmRealDecimal)